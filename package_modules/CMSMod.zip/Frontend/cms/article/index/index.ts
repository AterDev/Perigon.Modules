import { I18N_KEYS } from 'src/app/modules/share/i18n-keys';
import {
  ChangeDetectionStrategy,
  Component,
  inject,
  signal,
} from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonListModules } from 'src/app/modules/share/shared-modules';
import { AdminClient } from 'src/app/services/admin/admin-client';
import { ArticleItemDto } from 'src/app/services/admin/models/cmsmod/article-item-dto.model';
import { ArticleCategoryItemDto } from 'src/app/services/admin/models/cmsmod/article-category-item-dto.model';
import { TranslateService } from '@ngx-translate/core';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogComponent } from 'src/app/modules/share/components/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-article-index',
  imports: CommonListModules,
  templateUrl: './index.html',
  styleUrl: './index.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ArticleIndexComponent {
  readonly i18nKeys = I18N_KEYS;
  private readonly client = inject(AdminClient);
  private readonly snackBar = inject(MatSnackBar);
  private readonly translate = inject(TranslateService);
  private readonly dialog = inject(MatDialog);
  readonly articles = signal<ArticleItemDto[]>([]);
  readonly categories = signal<ArticleCategoryItemDto[]>([]);
  readonly loading = signal(false);
  title = '';
  catalogId = '';
  constructor() {
    this.client.articleCategory
      .list(null, 1, 100, null)
      .subscribe((page) => this.categories.set(page.data));
    this.load();
  }
  load(): void {
    this.loading.set(true);
    this.client.article
      .list(
        this.title || null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        null,
        this.catalogId || null,
        null,
        1,
        50,
        null,
      )
      .subscribe({
        next: (page) => {
          this.articles.set(page.data);
          this.loading.set(false);
        },
        error: () => this.loading.set(false),
      });
  }
  remove(item: ArticleItemDto): void {
    this.dialog
      .open(ConfirmDialogComponent, {
        data: {
          title: this.translate.instant(this.i18nKeys.common.confirmDelete),
          content:
        this.translate.instant(this.i18nKeys.cms.article.deleteConfirm, {
          title: item.title,
        }),
        },
      })
      .afterClosed()
      .subscribe((confirmed) => {
        if (!confirmed) return;
        this.client.article.delete(item.id).subscribe(() => {
          this.snackBar.open(
            this.translate.instant(this.i18nKeys.cms.article.deleteSuccess),
            this.translate.instant(this.i18nKeys.common.close),
            { duration: 2500 },
          );
          this.load();
        });
      });
  }
}
