namespace CMSMod.Models.ArticleCategoryDtos;

/// <summary>
/// 目录列表元素
/// </summary>
/// <inheritdoc cref="ArticleCategory"/>
public class ArticleCategoryItemDto
{
    /// <summary>
    /// 目录名称
    /// </summary>
    [StringLength(50)]
    public string Name { get; set; } = default!;

    /// <summary>
    /// 层级
    /// </summary>
    public short Level { get; set; }
    public Guid? ParentId { get; set; }
    public Guid Id { get; set; } = Guid.NewGuid();
    public DateTimeOffset CreatedTime { get; set; } = DateTimeOffset.UtcNow;
}
