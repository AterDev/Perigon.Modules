using EntityFramework.AppDbFactory;
using Perigon.AspNetCore.Options;
using System.Text.Json;
using SystemMod.Serialization;
using SystemMod.Models.SysConfigDtos;

namespace SystemMod.Managers;

/// <summary>
/// 系统配置
/// </summary>
public class SysConfigManager(
    AppDbFactory dbContextFactory,
    ILogger<SysConfigManager> logger,
    IUserContext userContext,
    IConfiguration configuration,
    CacheService cache
) : ManagerBase<DefaultDbContext, SysConfig>(dbContextFactory, userContext, logger)
{
    private readonly IConfiguration _configuration = configuration;
    private readonly CacheService _cache = cache;

    /// <summary>
    /// 当前用户所拥有的对象
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    public async Task<SysConfig?> GetOwnedAsync(Guid id)
    {
        IQueryable<SysConfig> query = _dbSet.Where(q => q.Id == id);
        // 获取用户所属的对象
        return await query.FirstOrDefaultAsync();
    }

    /// <summary>
    /// 获取登录安全策略
    /// </summary>
    /// <returns></returns>
    public async Task<LoginSecurityPolicyOption> GetLoginSecurityPolicyAsync()
    {
        // 优先级：缓存>配置文件
        var policy = new LoginSecurityPolicyOption();
        var configString = await _cache.GetValueAsync<string>(
            GetLoginSecurityPolicyCacheKey()
        );
        if (!string.IsNullOrWhiteSpace(configString))
        {
            policy = JsonSerializer.Deserialize(
                    configString,
                    SystemModJsonSerializerContext.Default.LoginSecurityPolicyOption)
                ?? new LoginSecurityPolicyOption();
        }
        else
        {
            var config = _configuration.GetSection(LoginSecurityPolicyOption.ConfigPath);
            if (config.Exists())
            {
                policy = config.Get<LoginSecurityPolicyOption>();
            }
        }
        return policy ?? new LoginSecurityPolicyOption();
    }

    public static string GetLoginSecurityPolicyCacheKey()
    {
        return WebConst.LoginSecurityPolicy;
    }

    /// <summary>
    /// Add system config
    /// </summary>
    public async Task<SysConfig> AddAsync(SysConfigAddDto dto)
    {
        var entity = new SysConfig { Key = dto.Key, Value = dto.Value, Description = dto.Description, Valid = dto.Valid, IsSystem = dto.IsSystem, GroupName = dto.GroupName ?? string.Empty };
        await InsertAsync(entity);
        return entity;
    }

    /// <summary>
    /// Edit system config
    /// </summary>
    public async Task<int> EditAsync(Guid id, SysConfigUpdateDto dto)
    {
        if (!await HasPermissionAsync(id))
        {
            throw new BusinessException(Localizer.NoPermission);
        }

        var current = await _dbSet.Where(config => config.Id == id).FirstOrDefaultAsync()
            ?? throw new BusinessException(Localizer.NotFoundResource, StatusCodes.Status404NotFound);
        if (dto.Key is not null)
        {
            current.Key = dto.Key;
        }

        if (dto.Value is not null)
        {
            current.Value = dto.Value;
        }

        if (dto.Description is not null)
        {
            current.Description = dto.Description;
        }

        if (dto.Valid is bool valid)
        {
            current.Valid = valid;
        }

        if (dto.GroupName is not null)
        {
            current.GroupName = dto.GroupName;
        }

        return await _dbSet
            .Where(config => config.Id == id)
            .ExecuteUpdateAsync(update => update
                .Set(config => config.Key, current.Key)
                .Set(config => config.Value, current.Value)
                .Set(config => config.Description, current.Description)
                .Set(config => config.Valid, current.Valid)
                .Set(config => config.GroupName, current.GroupName));
    }

    /// <summary>
    /// Get detail
    /// </summary>
    public async Task<SysConfigDetailDto?> GetAsync(Guid id)
    {
        return await FindAsync(MapDetail, c => c.Id == id);
    }

    /// <summary>
    /// Filter (pagination)
    /// </summary>
    public async Task<PageList<SysConfigItemDto>> FilterAsync(SysConfigFilterDto filter)
    {
        Queryable = Queryable
            .WhereNotNull(
                filter.Key,
                q => q
                    .Key
                    .ToLower()
                    .Contains(filter.Key!.ToLower())
            )
            .WhereNotNull(filter.GroupName, q => q.GroupName == filter.GroupName);

        return await PageListAsync<SysConfigFilterDto, SysConfigItemDto>(filter, MapItem);
    }

    /// <summary>
    /// Delete
    /// </summary>
    public async Task<int> DeleteAsync(Guid id)
    {
        if (await HasPermissionAsync(id))
        {
            return await DeleteOrUpdateAsync([id], false);
        }
        throw new BusinessException(Localizer.NoPermission);
    }

    private static SysConfigDetailDto MapDetail(SysConfig x) => new() { Key = x.Key, Description = x.Description, Valid = x.Valid, IsSystem = x.IsSystem, GroupName = x.GroupName };
    private static SysConfigItemDto MapItem(SysConfig x) => new() { Id = x.Id, Key = x.Key, Value = x.Value, Description = x.Description, Valid = x.Valid, IsSystem = x.IsSystem, GroupName = x.GroupName };

    public override Task<bool> HasPermissionAsync(Guid id)
    {
        // Allow the object when it exists in the database.
        var query = _dbSet.Where(q => q.Id == id);
        return query.AnyAsync();
    }
}
