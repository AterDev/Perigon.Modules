namespace SystemMod.Models.SysConfigDtos;

/// <summary>
/// 系统配置查询筛选
/// </summary>
/// <see cref="SysConfig"/>
public class SysConfigFilterDto : FilterBase
{
    [StringLength(100)]
    public string? Key { get; set; }

    /// <summary>
    /// 组
    /// </summary>
    public string? GroupName { get; set; }
}
