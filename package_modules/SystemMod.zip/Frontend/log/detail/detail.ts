import { ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonListModules } from '../../../share/shared-modules';
@Component({
  selector: 'app-system-log-detail',
  imports: CommonListModules,
  templateUrl: './detail.html',
  styleUrl: './detail.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SystemLogDetailComponent {}
