import {
  ChangeDetectionStrategy,
  Component,
  inject,
  signal,
} from '@angular/core';
import { CommonListModules } from '../../../share/shared-modules';
import { AdminClient } from '../../../../services/admin/admin-client';
import { SystemLogsItemDto } from '../../../../services/admin/models/system-mod/system-logs-item-dto.model';
@Component({
  selector: 'app-system-log-index',
  imports: CommonListModules,
  templateUrl: './index.html',
  styleUrl: './index.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SystemLogIndexComponent {
  private readonly client = inject(AdminClient);
  readonly logs = signal<SystemLogsItemDto[]>([]);
  readonly loading = signal(false);
  actionUserName = '';
  targetName = '';

  constructor() {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.client.systemLogs
      .filter({
        actionUserName: this.actionUserName || null,
        targetName: this.targetName || null,
        pageIndex: 1,
        pageSize: 100,
      })
      .subscribe({
        next: (page) => {
          this.logs.set(page.data);
          this.loading.set(false);
        },
        error: () => this.loading.set(false),
      });
  }
}
