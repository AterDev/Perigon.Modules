import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { I18N_KEYS } from 'src/app/modules/share/i18n-keys';
import { CommonListModules } from 'src/app/modules/share/shared-modules';
import { AdminClient } from 'src/app/services/admin/admin-client';
import { SystemLogsItemDto } from 'src/app/services/admin/models/system-mod/system-logs-item-dto.model';

@Component({
  selector: 'app-system-log-index',
  imports: CommonListModules,
  templateUrl: './index.html',
  styleUrl: './index.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SystemLogIndexComponent {
  readonly i18nKeys = I18N_KEYS;
  private readonly client = inject(AdminClient);
  readonly logs = signal<SystemLogsItemDto[]>([]);
  readonly loading = signal(false);
  actionUserName = '';
  targetName = '';

  constructor() {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.client.systemLogs
      .filter({
        actionUserName: this.actionUserName || null,
        targetName: this.targetName || null,
        pageIndex: 1,
        pageSize: 100,
      })
      .subscribe({
        next: (page) => {
          this.logs.set(page.data);
          this.loading.set(false);
        },
        error: () => this.loading.set(false),
      });
  }
}
