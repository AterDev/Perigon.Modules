namespace Entity.SystemMod;

/// <summary>
/// 系统配置
/// </summary>
public class SysConfig : EntityBase
{
    [StringLength(100)]
    [Required]
    public string Key { get; set; } = string.Empty;

    /// <summary>
    /// 以json字符串形式存储
    /// </summary>
    [StringLength(2000)]
    public string Value { get; set; } = string.Empty;

    [StringLength(500)]
    public string? Description { get; set; }
    public bool Valid { get; set; } = true;

    /// <summary>
    /// 是否属于系统配置
    /// </summary>
    public bool IsSystem { get; set; }

    /// <summary>
    /// 组
    /// </summary>
    [StringLength(60)]
    public string GroupName { get; set; } = string.Empty;

    /// <summary>
    /// 创建系统配置
    /// </summary>
    /// <param name="groupName">分组名称</param>
    /// <param name="key"></param>
    /// <param name="value"></param>
    /// <returns></returns>
    public static SysConfig NewSysConfig(string groupName, string key, string value)
    {
        return new SysConfig
        {
            Key = key,
            Value = value,
            GroupName = groupName,
            IsSystem = true,
        };
    }
}
